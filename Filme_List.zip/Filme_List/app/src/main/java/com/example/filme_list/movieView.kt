package com.example.filme_list

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class movieView : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movie_view)
    }



    fun trocar(view: View){
        val intent = Intent(this, search::class.java)
        startActivity(intent)
    }
}
