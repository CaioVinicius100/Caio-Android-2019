package com.example.filme_list

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun trocartela(view: View){
        val usuario1 = login.text.toString()
        val senha1 = password.text.toString()
        // val intent = Intent(this, activity_movie_view::class.java)
        val intent = Intent(this,movieView)

        if (login.text.isNullOrEmpty() || password.text.isNullOrEmpty())
        {
            Toast.makeText(applicationContext, "Digite as informações corretamente!", Toast.LENGTH_LONG)
        }
        else {
            // Verificar no banco de dados se o usuario1 e senha1 corresponde a algum dos login cadastrados
            auth.signInWithEmailAndPassword(usuario1, senha1)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        // Sign in success, update UI with the signed-in user's information
                        Log.d("Somente um teste", "signInWithEmail:success")
                        val user = auth.currentUser
                        updateUI(user)
                        startActivity(intent)
                    } else {
                        // If sign in fails, display a message to the user.
                        Log.w("teste caraio", "signInWithEmail:failure", task.exception)
                        Toast.makeText(
                            baseContext, "E-mail ou senha incorretos.",
                            Toast.LENGTH_SHORT
                        ).show()
                        updateUI(null)
                    }
                }
        }
    }

    fun cadastrar(view: View){
        val intent = Intent(this, cadastroactivity::class.java)
        startActivity(intent)
    }
}
