package com.example.filme_list

import android.os.Bundle
import android.support.v7.app.AppCompatActivity


class cadastroactivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.cadastro)
    }

}