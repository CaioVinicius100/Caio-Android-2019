package com.idelbrando.projetobaseatividadet1_2019_eca804

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1)

        listView.adapter = adapter

        btnAdd.setOnClickListener {
            if(editTextNomeProduto.text.isEmpty() || editTextQuantProd.text.isEmpty())
            {
                editTextNomeProduto.error = "Digite as informações corretamente"
            }
            else
            {
                val exibir = editTextNomeProduto.text.toString() + " - " + editTextQuantProd.text.toString()
                adapter.add(exibir)
                editTextNomeProduto.text.clear()
                editTextQuantProd.text.clear()
            }
        }
    }
}
