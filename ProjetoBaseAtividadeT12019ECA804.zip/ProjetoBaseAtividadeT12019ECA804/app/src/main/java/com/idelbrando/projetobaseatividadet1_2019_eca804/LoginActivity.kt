package com.idelbrando.projetobaseatividadet1_2019_eca804

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)



    }
        fun TrocaTela(view:View)
        {
            val usuario = "admin"
            val senha = "admin"
            val usuario1 = editTextUsuario.text.toString()
            val senha1 = editTextSenha.text.toString()
            val intent = Intent(this,MainActivity::class.java)
            if((usuario1 == usuario) && (senha1 == senha))
            {
                startActivity(intent)
            }
        }

}
